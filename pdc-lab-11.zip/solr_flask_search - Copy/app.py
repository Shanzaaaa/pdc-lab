from flask import Flask, request, render_template, jsonify
import requests

app = Flask(__name__)

SOLR_URL = "http://localhost:8983/solr/jcgArticles/select"

def solr_search(query, filter_category=None, filter_published=None, sort_order=None):
    # Base query construction similar to the old code
    base_query = f"title:*{query}* OR category:*{query}* OR author:*{query}*"
    filters = []

    if filter_category:
        filters.append(f"category:{filter_category}")
    if filter_published:
        filters.append(f"published:{filter_published}")
    if sort_order:
        sort = f"title {sort_order}"
    else:
        sort = ""

    params = {
        'q': base_query,
        'wt': 'json',
        'sort': sort
    }
    
    if filters:
        params['fq'] = filters

    response = requests.get(SOLR_URL, params=params)
    # Return docs from the response similar to the old code
    try:
        return response.json()["response"]["docs"]
    except KeyError as e:
        print(f"KeyError: {e} - Response structure might be different.")
        return []  # Return an empty list if there's an error

@app.route("/")
def index():
    query = request.args.get("q", "")
    filter_category = request.args.get("category")
    filter_published = request.args.get("published")
    sort_order = request.args.get("sort")
    results = []

    if query:
        results = solr_search(query, filter_category, filter_published, sort_order)

    return render_template("index.html", results=results, query=query)

@app.route("/autocomplete")
def autocomplete():
    term = request.args.get("term", "")
    docs = solr_search(term)
    titles = [doc.get("title", "") for doc in docs]
    return jsonify(titles)

if __name__ == "__main__":
    app.run(debug=True)
